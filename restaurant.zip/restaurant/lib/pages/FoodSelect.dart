import 'package:flutter/material.dart';
import 'Drink.dart';

class FoodSelect extends StatefulWidget {
  @override
  _FoodSelectState createState() => _FoodSelectState();
}

class _FoodSelectState extends State<FoodSelect> {
  List<Drink> drinks = [
    Drink("Coffee", 5),
    Drink("Black Tea", 3),
    Drink("Green Tea", 3),
    Drink("Lemonade", 4),
    Drink("Apple Juice", 4),
    Drink("Orange Juice", 4),
    Drink("Beer", 7),
    //Drink("Cocktail", 15)
  ];

  Widget generateRow(Drink drink) {
    return Container(
      margin: EdgeInsets.all(10),
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 2,
            child: Container(
              padding: EdgeInsets.all(20),
              child: Text(drink.name, style: TextStyle(fontSize: 15)),
              color: Colors.green[600],
            ),
          ),
          Expanded(
              child: FlatButton.icon(
            onPressed: () {
              setState(() {
                drink.removeOrder();
              });
            },
            label: Text(''),
            icon: Icon(Icons.arrow_back_ios),
            color: Colors.grey,
          )),
          Expanded(
            child: Container(
              padding: EdgeInsets.fromLTRB(15, 8, 15, 8),
              child: Container(
                padding: EdgeInsets.all(5),
                  color: Colors.white,
                  child: Text(
                    drink.numOrd.toString(),
                    style: TextStyle(fontSize: 15),
                  )),
              color: Colors.green[600],
            ),
          ),
          Expanded(
              child: FlatButton.icon(
            onPressed: () {
              setState(() {
                drink.addOrder();
              });
            },
            label: Text(''),
            icon: Icon(Icons.arrow_forward_ios),
            color: Colors.grey,
          )),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('FoodSelect'),
        backgroundColor: Colors.green[600],
      ),
      body:
      Column(
        children: <Widget>[
          Expanded(
            flex: 10,
            child: Column(
              children: drinks.map((drink) => generateRow(drink)).toList(),
            ),
          ),
          Expanded(

              child: Container(
                padding: EdgeInsets.fromLTRB(0, 0, 0, 5),
                child: FlatButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/shopping_cart', arguments: {
                      'drinks': this.drinks,
                    });
                  },
                  color: Colors.green[600],
                  child: Text('Go to Shopping Cart')
                ),
              )
          )
        ],
      )

    );
  }
}
