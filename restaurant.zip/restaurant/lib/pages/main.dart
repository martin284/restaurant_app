import 'package:flutter/material.dart';
import 'package:restaurant/pages/FoodSelect.dart';
import 'package:restaurant/pages/ShoppingCart.dart';
import 'package:restaurant/pages/ThankYou.dart';

void main() => runApp(MaterialApp(routes: {
  '/': (context) => FoodSelect(),
  '/shopping_cart': (context) => ShoppingCart(),
  '/thank_you': (context) => ThankYou(),
}));
