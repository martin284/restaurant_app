import 'package:flutter/material.dart';
import 'Drink.dart';

class ShoppingCart extends StatefulWidget {
  @override
  _ShoppingCartState createState() => _ShoppingCartState();
}

class _ShoppingCartState extends State<ShoppingCart> {
  Widget generateRow(Drink drink) {
    return Container(
      margin: EdgeInsets.all(10),
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 2,
            child: Container(
              padding: EdgeInsets.all(20),
              child: Text(
                drink.numOrd.toString() + ' x ' + drink.name,
                style: TextStyle(fontSize: 16),
              ),
              color: Colors.green[600],
            ),
          ),
          Expanded(
            child: Container(
              padding: EdgeInsets.all(20),
              child: Text((drink.numOrd * drink.price).toString() + '€',
                  style: TextStyle(fontSize: 16)),
              color: Colors.green[600],
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    //reads the data from the previous screen
    Map drinksMap = ModalRoute.of(context).settings.arguments;
    List<Drink> drinks = drinksMap['drinks'];
    List<Drink> drinksOrdered = new List();
    int totalPrice = 0;
    for (int i = 0; i < drinks.length; i++) {
      if (drinks[i].numOrd != 0) {
        totalPrice = totalPrice + drinks[i].numOrd * drinks[i].price;
        drinksOrdered.add(drinks[i]);
      }
    }

    List rows = drinksOrdered.map((drink) => generateRow(drink)).toList();

    return Scaffold(
        appBar: AppBar(
          title: Text('Shopping Cart'),
          backgroundColor: Colors.green[600],
        ),
        body: Column(
          children: <Widget>[
            Expanded(
                flex: 30,
                child: Container(
                  color: Colors.white,
                  child: Column(
                    children: rows,
                  ),
                )),
            Expanded(
              flex: 2,
              child: Container(
                  color: Colors.white,
                  child: Center(
                    child: Text(
                      'Price in total: ' + totalPrice.toString() + '€',
                      style: TextStyle(fontSize: 20),
                    ),
                  )),
            ),
            Expanded(
                flex: 4,
                child: Container(
                  color: Colors.grey[800],
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                  child: FlatButton(
                      onPressed: () {
                        Navigator.pushNamed(context, '/thank_you');
                      },
                      child: Text('Place your order',
                          style: TextStyle(fontSize: 20)),
                      color: Colors.green[600]),
                ))
          ],
        ));
  }
}
