import 'package:flutter/material.dart';

class ThankYou extends StatefulWidget {
  @override
  _ThankYouState createState() => _ThankYouState();
}

class _ThankYouState extends State<ThankYou> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Column(
        children: <Widget>[
          Expanded(flex: 10, child: Center(
              child: Container(
                color: Colors.green,
                padding: EdgeInsets.all(20),
                child: Text('Thank You',
                style: TextStyle(fontWeight: FontWeight.bold,
                fontSize: 50) ,
                ),
              ))),
          Expanded(
            flex: 1,
            child: Container(
              padding: EdgeInsets.fromLTRB(0, 0, 0, 5),
              child: FlatButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
                color: Colors.green,
                child: Text('OKAY'),
              ),
            ),
          )
        ],
      )),
    );
  }
}
