class Drink {
  //name of the drink
  String name;

  //price per order
  int price;

  //number of orders
  int numOrd;

  Drink(String name, int price) {
    this.name = name;
    this.price = price;
    this.numOrd = 0;
  }

  void addOrder() {
    numOrd += 1;
  }

  void removeOrder() {
    if (numOrd > 0) {
      numOrd -= 1;
    }
  }

  int getNumOrd() {
    return numOrd;
  }
}
