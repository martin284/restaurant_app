import 'package:flutter/material.dart';
import 'Drink.dart';

class ShoppingCart extends StatefulWidget {
  @override
  _ShoppingCartState createState() => _ShoppingCartState();
}

class _ShoppingCartState extends State<ShoppingCart> {
  Widget generateRow(Drink drink) {
    return Container(
      margin: EdgeInsets.all(10),
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 2,
            child: Container(
              padding: EdgeInsets.all(20),
              child: Text(drink.numOrd.toString() + ' x ' + drink.name),
              color: Colors.green,
            ),
          ),
          Expanded(
            child: Container(
              padding: EdgeInsets.all(20),
              child: Text((drink.numOrd * drink.price).toString() + '€'),
              color: Colors.green,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    //reads the data from the previous screen
    Map drinksMap = ModalRoute.of(context).settings.arguments;
    List<Drink> drinks = drinksMap['drinks'];
    List<Drink> drinksOrdered = new List();
    int totalPrice = 0;
    for (int i = 0; i < drinks.length; i++) {
      if (drinks[i].numOrd != 0) {
        totalPrice = totalPrice + drinks[i].numOrd * drinks[i].price;
        drinksOrdered.add(drinks[i]);
      }
    }
    Widget totalPriceAsText = new Container(
      child: Text('Price in total: ' + totalPrice.toString()),
    );
    List rows = drinksOrdered.map((drink) => generateRow(drink)).toList();
    rows.add(totalPriceAsText);

    Widget finalOrder = new FlatButton(
        onPressed: () {
          Navigator.pushNamed(context, '/thank_you');
        },
        child: Text('Bestellung abgeben'),
        color: Colors.green);
    rows.add(finalOrder);

    return Scaffold(
      appBar: AppBar(
        title: Text('Shopping Cart'),
        backgroundColor: Colors.green,
      ),
      body: Column(
        children: rows,
      ),
    );
  }
}
