import 'package:flutter/material.dart';
import 'Drink.dart';

class FoodSelect extends StatefulWidget {
  @override
  _FoodSelectState createState() => _FoodSelectState();
}

class _FoodSelectState extends State<FoodSelect> {
  List<Drink> drinks = [
    Drink("Coffee", 5),
    Drink("Black Tea", 3),
    Drink("Green Tea", 3),
    Drink("Cola", 4),
    Drink("Fanta", 4),
    Drink("Sprite", 4),
    Drink("Beer", 7),
    //Drink("Cocktail", 15)
  ];


  Widget generateRow(Drink drink) {
    return Container(
      margin: EdgeInsets.all(10),
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 2,
            child: Container(
              padding: EdgeInsets.all(20),
              child: Text(drink.name),
              color: Colors.green,
            ),
          ),
          Expanded(
              child: FlatButton.icon(
                onPressed: () {
                  setState(() {
                    drink.removeOrder();
                  });
                },
                label: Text(''),
                icon: Icon(Icons.arrow_back_ios),
                color: Colors.amber,
              )),
          Expanded(
            child: Container(
              padding: EdgeInsets.all(20),
              child: Text(drink.numOrd.toString()),
              color: Colors.green,
            ),
          ),
          Expanded(
              child: FlatButton.icon(
                onPressed: () {
                  setState(() {
                    drink.addOrder();
                  });
                },
                label: Text(''),
                icon: Icon(Icons.arrow_forward_ios),
                color: Colors.amber,
              )),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('FoodSelect'),
        backgroundColor: Colors.green,
        actions: <Widget>[
          Container(
              child: FlatButton.icon(
                onPressed: () {
                  Navigator.pushNamed(context, '/shopping_cart', arguments: {
                    'drinks': this.drinks,
                  });
                },
                color: Colors.green,
                icon: Icon(Icons.arrow_forward_ios),
                label: Text(''),
              ))
        ],
      ),
      body: (Column(
        children: drinks.map((drink) => generateRow(drink)).toList(),
      )),
    );
  }
}
