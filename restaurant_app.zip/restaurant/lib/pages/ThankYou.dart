import 'package:flutter/material.dart';

class ThankYou extends StatefulWidget {
  @override
  _ThankYouState createState() => _ThankYouState();
}

class _ThankYouState extends State<ThankYou> {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Text('Thank You'),
            FlatButton(
              onPressed: (){
                Navigator.pushNamed(context, '/');
              },
              color: Colors.green,
              child: Text('OKAY'),
            )
          ],
        )
      ),
    );
  }
}
